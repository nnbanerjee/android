package com.medico.view;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;


public class SigninActivity extends FragmentActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.medico.application.R.layout.activity_sigin);
    }
}
