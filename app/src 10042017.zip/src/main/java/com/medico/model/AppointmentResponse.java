package com.medico.model;

/**
 * Created by Narendra on 12-03-2017.
 */

public class AppointmentResponse
{
    public Integer appointmentId;
    public Byte status;
    public String errorCode;
}
