package com.medico.model;

import java.util.List;

/**
 * Created by Narendra on 05-04-2017.
 */

public class JsonResponse
{
    public List<?> response;
    public Integer status;
    public String errorCode;
}
