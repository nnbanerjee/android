package com.medico.model;

import java.math.BigDecimal;

/**
 * Created by Narendra on 10-04-2017.
 */

public class FinanceSummary
{
    public Long date;
    public BigDecimal totalCost = new BigDecimal("0");
}
