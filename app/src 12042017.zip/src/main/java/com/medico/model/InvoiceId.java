package com.medico.model;

/**
 * Created by Narendra on 02-04-2016.
 */
public class InvoiceId {
    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    public InvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }

    private Integer invoiceId;
}
