package com.medico.model;

/**
 * Created by Narendra on 09-03-2016.
 */
public class MedicineId {
    public Integer getMedicineId() {
        return medicineId;
    }

    public void setMedicineId(Integer medicineId) {
        this.medicineId = medicineId;
    }

    public MedicineId(Integer medicineId) {
        this.medicineId = medicineId;
    }

    private Integer medicineId;
}
