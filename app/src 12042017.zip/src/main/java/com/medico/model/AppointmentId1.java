package com.medico.model;

/**
 * Created by Narendra on 20-02-2016.
 */
public class AppointmentId1 {

    public Integer getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public AppointmentId1(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    private Integer appointmentId;
}
