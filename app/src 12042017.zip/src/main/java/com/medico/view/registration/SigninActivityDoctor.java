package com.medico.view.registration;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;


public class SigninActivityDoctor extends FragmentActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.medico.application.R.layout.activity_sigin_doc);
    }
}
