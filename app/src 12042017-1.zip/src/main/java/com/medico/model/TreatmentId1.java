package com.medico.model;

/**
 * Created by Narendra on 19-04-2016.
 */
public class TreatmentId1 {
    public Integer getTreatmentId() {
        return treatmentId;
    }

    public void setTreatmentId(Integer treatmentId) {
        treatmentId = treatmentId;
    }

    public TreatmentId1(Integer treatmentId) {
        this.treatmentId = treatmentId;
    }

    private Integer treatmentId;

}
