package com.medico.model;

/**
 * Created by Narendra on 16-03-2017.
 */

public class ServerResponse
{
    public Integer status;
    public String errorCode;
}
