package com.medico.model;


public class DiagnosticTest
{
	public Integer testId;
	public Integer category;
	public String details;
	public String name;
	public Integer type;
	public String url;
	
	public DiagnosticTest() {
		
	}
	public String toString()
	{
		return name;
	}
}
