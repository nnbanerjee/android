package com.medico.model;

/**
 * Created by Narendra on 16-02-2016.
 */
public class forgotPassword {
    private String email;

    public forgotPassword(String type, String email) {
        this.email = email;

    }





    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }



}
