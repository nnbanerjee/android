package com.medico.model;

/**
 * Created by Narendra on 09-03-2016.
 */
public class PatientTestId {
    public String getPatientTestId() {
        return patientTestId;
    }

    public void setPatientTestId(String patientTestId) {
        this.patientTestId = patientTestId;
    }

    public PatientTestId(String patientTestId) {
        this.patientTestId = patientTestId;
    }

    private String patientTestId;
}
