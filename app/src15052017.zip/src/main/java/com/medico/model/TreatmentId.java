package com.medico.model;

/**
 * Created by Narendra on 24-04-2017.
 */

public class TreatmentId
{
    public Integer treatmentId;

    public TreatmentId(Integer treatmentId)
    {
        this.treatmentId = treatmentId;
    }
}
