package com.medico.model;

/**
 * Created by Narendra on 23-03-2017.
 */

public class ClinicId
{
    public Integer clinicId;

    public ClinicId(Integer clinicId)
    {
        this.clinicId = clinicId;
    }
}
