package com.medico.model;

/**
 * Created by Narendra on 12-05-2017.
 */

public class checkEmailAndMobileAvailabilityRequest
{
    public String email;
    public Long mobile;
}
