package com.medico.model;

/**
 * Created by Narendra on 19-04-2016.
 */
public class CustomId {
    public Integer getTreatmentId() {
        return treatmentId;
    }

    public void setTreatmentId(Integer treatmentId) {
        treatmentId = treatmentId;
    }

    public CustomId(Integer treatmentId) {
        this.treatmentId = treatmentId;
    }

    private Integer treatmentId;

}
