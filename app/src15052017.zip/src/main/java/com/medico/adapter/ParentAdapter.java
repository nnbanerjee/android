package com.medico.adapter;

import android.widget.BaseAdapter;

import com.medico.util.PARAM;

/**
 * Created by Narendra on 17-01-2017.
 */

public abstract class ParentAdapter extends BaseAdapter implements PARAM
{
}
