package com.medico.util;

/**
 * Created by Narendra on 05-04-2017.
 */

public interface NotifyListener
{
    public void notify(int id, Notifier source, Object parameter);
}
