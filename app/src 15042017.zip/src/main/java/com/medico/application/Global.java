package com.medico.application;

import android.app.Application;


/**
 * Created by MNT on 26-Mar-15.
 */
public class Global extends Application {


}
