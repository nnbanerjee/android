package com.medico.model;

/**
 * Created by User on 7/6/15.
 */
public class TimeReminder {

    String time;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
