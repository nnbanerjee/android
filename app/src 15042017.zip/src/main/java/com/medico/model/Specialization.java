package com.medico.model;

/**
 * Created by Narendra on 22-03-2017.
 */

public class Specialization
{
    public Integer id;
    public String name;
    public Integer practiceId;

    public String toString()
    {
        return name;
    }
}
