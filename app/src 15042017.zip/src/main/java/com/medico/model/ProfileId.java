package com.medico.model;

/**
 * Created by Narendra on 27-01-2017.
 */

public class ProfileId
{
    Integer profileId;

    public ProfileId(Integer profileId)
    {
        this.profileId = profileId;
    }

    public Integer getProfileId()
    {
        return profileId;
    }

    public void setProfileId(Integer profileId) {
        this.profileId = profileId;
    }


}
