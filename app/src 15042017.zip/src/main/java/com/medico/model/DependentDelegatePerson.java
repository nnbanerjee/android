package com.medico.model;

/**
 * Created by Narendra on 21-03-2017.
 */

public class DependentDelegatePerson extends Person
{
    public Integer primePersonId;
    public Byte accessLevel;
    public String relation;
    public Byte delegationStatus;
    public Byte type;
}
